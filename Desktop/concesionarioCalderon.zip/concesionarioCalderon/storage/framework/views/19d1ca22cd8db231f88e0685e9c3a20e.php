<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Concesionario Calderon</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="dns-prefetch" href="//fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=Nunito" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="icon" type="image/jpg" href="<?php echo e(URL::asset('assets/logo.png')); ?>"/>

    <style>
        body, html {
            height: 100%;
            margin: 0;
            overflow-x: hidden;
            position: relative;
        }

        /* navbar */
        .navbar {
            margin-left: 15px;
            position: absolute;
            width: 100%;
            z-index: 1000;
        }

        .navbar-nav .nav-link {
            color: #ffffff !important;
        }

        /* video */
        .video-container {
            position: relative;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            overflow: hidden;
            z-index: -1;
        }

        .video-container video {
            min-width: 100%;
            min-height: 100%;
            width: auto;
            height: auto;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
        }

        /* logos */
        .logos {
            font-size: 0;
            text-align: center;
            padding: 30px;
        }

        .logos h2 {
            margin-bottom: 45px;
            margin-top: 35px;
        }

        .logos img {
            width: 100px;
            height: auto;
            margin: 0 80px;
            vertical-align: middle;
        }

        /* carousel */
        .container h2{
            text-align: center;
            padding: 30px;
        }

        .content-wrapper{
            float: left;
            width: 50%;
            height: 50%;
        }

        .content-wrapper img{
            width: 100%;
            height: 100%;
            border-radius: 10px;
        }

        #texto{
            float: right;
            width: 45%;
            height: 45%;
        }

        #texto h4{
            margin-top: 70px;
            margin-bottom: 10px;
        }

        #texto p{
            font-size: 18px;
        }

        .a{
            clear: both;
        }
    </style>
</head>
<body>

<!-- NAVBAR -->
<nav class="navbar navbar-expand-lg navbar-light" style="background-color: transparent;">
    <a class="navbar-brand" href="#"><img src="<?php echo e(URL::asset('assets/logo.png')); ?>" width="65px" height="65px"></a>

    <ul class="navbar-nav">
        <li class="nav-item active linkNavbar">
            <a class="nav-link" href="#">Modelos</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="#">Electricos</a>
        </li>
        <li class="nav-item dropdown">
            <a class="nav-link" href="#" id="navbarDropdown" role="button"> Servicio</a>
        </li>
        <li class="nav-item dropdown">
            <a class="nav-link" href="#" id="navbarDropdown" role="button"> Reparaciones</a>
        </li>
        <li class="nav-item dropdown">
            <a class="nav-link" href="#" id="navbarDropdown" role="button"> Quienes somos</a>
        </li>

        <div class="d-flex justify-content-end">
            <li class="nav-item">
                <a class="nav-link" href="#"><i class="fa-solid fa-user"></i></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#"><i class="fa-solid fa-location-dot"></i></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#"><i class="fa-solid fa-cart-shopping"></i></a>
            </li>
        </div>

    </ul>
</nav>
<!-- FIN NAVBAR -->

<!-- Video -->
<div class="video-container">
    <video autoplay muted loop>
        <source src="<?php echo e(URL::asset('assets/videoInicio.mp4')); ?>" type="video/mp4">
    </video>
</div>
<!-- Fin video -->

<!-- Logos -->
<div class="logos">
    <h2>Nuestras Mejores Marcas</h2>
    <a href="#"><img src="<?php echo e(URL::asset('assets/logosMarca/logoAudi.png')); ?>"></a>
    <a href="#"><img src="<?php echo e(URL::asset('assets/logosMarca/logoFerrari.jpeg')); ?>"></a>
    <a href="#"><img src="<?php echo e(URL::asset('assets/logosMarca/logoPorche.jpeg')); ?>"></a>
    <a href="#"><img src="<?php echo e(URL::asset('assets/logosMarca/logoVolkwagen.png')); ?>"></a>
    <a href="#"><img src="<?php echo e(URL::asset('assets/logosMarca/logoBmw.png')); ?>"></a>
</div>
<!-- Fin logos -->

<!-- Carousel -->
<div class="container">
    <h2>Concesionario Calderón: Tu Destino De Confianza</h2>
    <div class="content-wrapper">
        <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
            <ol class="carousel-indicators">
                <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
                <li data-target="#carouselExampleIndicators" data-slide-to="3"></li>
                <li data-target="#carouselExampleIndicators" data-slide-to="4"></li>
            </ol>
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img class="d-block" src="<?php echo e(asset('assets/imagesCarousel/audirsq8.jpeg')); ?>" alt="First slide">
                </div>
                <div class="carousel-item">
                    <img class="d-block" src="<?php echo e(asset('assets/imagesCarousel/bmwx6.jpeg')); ?>" alt="Second slide">
                </div>
                <div class="carousel-item">
                    <img class="d-block" src="<?php echo e(asset('assets/imagesCarousel/ferrariroma.jpeg')); ?>" alt="Third slide">
                </div>
                <div class="carousel-item">
                    <img class="d-block" src="<?php echo e(asset('assets/imagesCarousel/porsche911.jpeg')); ?>" alt="Fourth slide">
                </div>
                <div class="carousel-item">
                    <img class="d-block" src="<?php echo e(asset('assets/imagesCarousel/volkswagengolf.jpeg')); ?>" alt="Fifth slide">
                </div>
            </div>
            <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>
        </div>
    </div>

    <div id="texto">
        <h4>Experiencia Automotriz en Concesionario Calderón</h4>
        <p>En Concesionario Calderón, te ofrecemos una experiencia automotriz excepcional.
        Desde la selección de tu vehículo ideal hasta el mantenimiento posterior a la compra,
        nuestro equipo experto está aquí para ayudarte en cada paso del camino. Confía en nosotros
        para brindarte calidad, transparencia y un servicio personalizado.
        ¡Visítanos hoy y descubre por qué somos tu mejor opción en automóviles!</p>
    </div>
</div>
<!-- Fin Carousel -->

<div class="a">
    <p>flñdjfjlsdafjlasdn</p>
</div>



<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-p34f1UUtsS3wqzfto5wAAmdvj+osOnFyQFpp4Ua3gs/ZVWx6oOypYoCJhGGScy+8" crossorigin="anonymous"></script>
</body>
</html>
<?php /**PATH /var/www/html/resources/views/welcome.blade.php ENDPATH**/ ?>